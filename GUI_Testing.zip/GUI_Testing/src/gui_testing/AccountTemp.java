
package gui_testing;


public class AccountTemp {
    String user;
    String pass;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public AccountTemp(String user, String pass) {
        this.user = user;
        this.pass = pass;
    }
    
    
    
    
    
    
}
