package gui_testing;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

public class GUI_Testing {

    public static ArrayList<AccountTemp> accounts = new ArrayList<>();
    public static boolean userflag = false;
    public static boolean passflag = false;
    public static Menu menu = new Menu();

    public static void main(String[] args) {
        String dir = System.getProperty("user.dir") + "\\AccountData.txt";
        write(dir);
        menu.setVisible(true);

    }

    public static void write(String dir) {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter(dir, true));
            
            for (int i = 0; i <accounts.size() ; i++) {
                pw.println(accounts.get(i).user);
                pw.println(accounts.get(i).pass);
            }
            

        } catch (Exception e) {

        }

    }

}
